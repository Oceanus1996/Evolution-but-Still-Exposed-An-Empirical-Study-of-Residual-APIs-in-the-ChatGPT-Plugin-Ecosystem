
import asyncio
import aiohttp
import json
import pandas as pd
from pathlib import Path
from datetime import datetime
import sys
import yaml

BASE = Path(__file__).resolve().parent.parent
CONCURRENT = 20
TIMEOUT = 15


async def fetch_spec(session: aiohttp.ClientSession, url: str) -> dict | None:
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=TIMEOUT),
                               ssl=False) as resp:
            if resp.status != 200:
                return None
            text = await resp.text()

            try:
                return json.loads(text)
            except json.JSONDecodeError:
                pass

            try:
                return yaml.safe_load(text)
            except Exception:
                pass

            return None
    except Exception:
        return None


def extract_endpoints_from_spec(spec: dict) -> list[dict]:
    endpoints = []
    paths = spec.get("paths", {})
    if not isinstance(paths, dict):
        return endpoints

    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method, details in methods.items():
            if method.lower() in ("get", "post", "put", "patch", "delete", "head", "options"):
                summary = ""
                description = ""
                if isinstance(details, dict):
                    summary = details.get("summary", "") or ""
                    description = details.get("description", "") or ""

                    params = details.get("parameters", [])
                    param_names = []
                    if isinstance(params, list):
                        for p in params:
                            if isinstance(p, dict):
                                param_names.append(p.get("name", ""))

                endpoints.append({
                    "path": path,
                    "method": method.upper(),
                    "summary": str(summary)[:200],
                    "description": str(description)[:200],
                    "param_count": len(param_names) if param_names else 0,
                    "param_names": ",".join(param_names[:10]),
                })

    return endpoints


async def step_2_2(df: pd.DataFrame):
    print("\n" + "=" * 60)
    print("Step 2.2: Endpoint Capability Classification")
    print("=" * 60)

    targets = df[df["backend_status"] == "fully_alive"].copy()
    print(f"Target: {len(targets)} fully_alive plugins")
    print(f"  Auth distribution: {targets['manifest_auth_type'].value_counts().to_dict()}")

    sem = asyncio.Semaphore(CONCURRENT)
    all_endpoints = []

    async with aiohttp.ClientSession() as session:
        for idx, (_, row) in enumerate(targets.iterrows()):
            title = row["title"]
            api_url = str(row["manifest_api_url"]).strip()

            async with sem:
                spec = await fetch_spec(session, api_url)

            if spec is None:
                print(f"  [{idx+1}/{len(targets)}] {title}: FAILED to fetch spec")
                continue

            endpoints = extract_endpoints_from_spec(spec)
            if not endpoints:
                print(f"  [{idx+1}/{len(targets)}] {title}: no endpoints found in spec")
                continue

            server_base = row.get("api_server_base", "")
            auth_type = row.get("manifest_auth_type", "unknown")

            for ep in endpoints:
                all_endpoints.append({
                    "title": title,
                    "auth_type": auth_type,
                    "server_base": server_base,
                    "api_url": api_url,
                    "path": ep["path"],
                    "method": ep["method"],
                    "summary": ep["summary"],
                    "description": ep["description"],
                    "param_count": ep["param_count"],
                    "param_names": ep["param_names"],
                })

            print(f"  [{idx+1}/{len(targets)}] {title} [{auth_type}]: {len(endpoints)} endpoints")

    df_ep = pd.DataFrame(all_endpoints)

    out_path = BASE / "dataset" / "rq2_endpoint_classification.xlsx"
    df_ep.to_excel(str(out_path), index=False)
    print(f"\nSaved: {out_path}")

    print(f"\n--- Step 2.2 Summary ---")
    print(f"Total plugins with specs fetched: {df_ep['title'].nunique()}")
    print(f"Total endpoints extracted: {len(df_ep)}")

    if len(df_ep) > 0:
        print(f"\nHTTP method distribution:")
        print(df_ep["method"].value_counts().to_string())

        print(f"\n--- By Auth Type ---")
        for auth in df_ep["auth_type"].unique():
            sub = df_ep[df_ep["auth_type"] == auth]
            n_plugins = sub["title"].nunique()
            n_eps = len(sub)
            print(f"  {auth}: {n_plugins} plugins, {n_eps} endpoints")

    return df_ep


async def step_2_3(df: pd.DataFrame):
    print("\n" + "=" * 60)
    print("Step 2.3: Information Leakage Inventory")
    print("=" * 60)

    manifest = df[df["manifest_accessible"] == True].copy()
    print(f"Target: {len(manifest)} manifest-accessible plugins")

    records = []
    for _, row in manifest.iterrows():
        title = row["title"]
        auth = row.get("manifest_auth_type", "")
        api_url = str(row.get("manifest_api_url", ""))
        legal_url = str(row.get("manifest_legal_info_url", ""))
        email = str(row.get("manifest_contact_email", ""))
        server_base = str(row.get("api_server_base", ""))
        manifest_url = str(row.get("manifest_url", ""))
        name = str(row.get("manifest_name_for_human", ""))
        spec_accessible = row.get("api_spec_accessible", False)
        endpoint_count = row.get("api_endpoint_count", 0)
        backend_status = row.get("backend_status", "")

        leaks = []

        has_email = bool(email and email != "nan" and "@" in email)
        if has_email:
            leaks.append("email")

        has_legal = bool(legal_url and legal_url != "nan" and legal_url.startswith("http"))
        if has_legal:
            leaks.append("legal_url")

        has_api_url = bool(api_url and api_url != "nan" and ("http" in api_url or api_url.startswith("/")))
        if has_api_url:
            leaks.append("api_url")

        has_server = bool(server_base and server_base != "nan" and server_base.startswith("http"))
        if has_server:
            leaks.append("server_base")

        if spec_accessible:
            leaks.append("full_spec")

        if backend_status == "fully_alive":
            leaks.append("live_endpoints")

        if backend_status == "fully_alive" and auth == "none":
            severity = "critical"
        elif backend_status == "fully_alive":
            severity = "high"
        elif spec_accessible:
            severity = "medium"
        else:
            severity = "low"

        records.append({
            "title": title,
            "manifest_url": manifest_url,
            "auth_type": auth,
            "backend_status": backend_status,
            "has_email": has_email,
            "email": email if has_email else "",
            "has_legal_url": has_legal,
            "legal_url": legal_url if has_legal else "",
            "has_api_url": has_api_url,
            "api_url": api_url if has_api_url else "",
            "has_server_base": has_server,
            "server_base": server_base if has_server else "",
            "spec_downloadable": bool(spec_accessible),
            "endpoint_count": endpoint_count if spec_accessible else 0,
            "live_endpoints": backend_status == "fully_alive",
            "leak_count": len(leaks),
            "leak_types": ",".join(leaks),
            "severity": severity,
        })

    df_leak = pd.DataFrame(records)

    out_path = BASE / "dataset" / "rq2_info_leakage.xlsx"
    df_leak.to_excel(str(out_path), index=False)
    print(f"\nSaved: {out_path}")

    print(f"\n--- Step 2.3 Summary ---")
    print(f"Total manifest-accessible plugins: {len(df_leak)}")

    print(f"\nInformation leakage counts:")
    print(f"  Contact email exposed: {df_leak['has_email'].sum()}")
    print(f"  Legal info URL exposed: {df_leak['has_legal_url'].sum()}")
    print(f"  API endpoint URL exposed: {df_leak['has_api_url'].sum()}")
    print(f"  Server base URL exposed: {df_leak['has_server_base'].sum()}")
    print(f"  Full API spec downloadable: {df_leak['spec_downloadable'].sum()}")
    print(f"  Live endpoints reachable: {df_leak['live_endpoints'].sum()}")

    print(f"\nSeverity distribution:")
    print(df_leak["severity"].value_counts().to_string())

    print(f"\nLeak count distribution (items per plugin):")
    print(df_leak["leak_count"].value_counts().sort_index().to_string())

    print(f"\nAuth type vs severity:")
    cross = pd.crosstab(df_leak["auth_type"], df_leak["severity"])
    print(cross.to_string())

    emails = df_leak[df_leak["has_email"]]["email"]
    if len(emails) > 0:
        domains = emails.apply(lambda x: x.split("@")[-1] if "@" in str(x) else "")
        print(f"\nUnique email domains exposed: {domains.nunique()}")
        print(f"Top email domains:")
        print(domains.value_counts().head(10).to_string())

    return df_leak


async def main():
    print(f"=== RQ2 Attack Surface Analysis — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")

    df = pd.read_excel(BASE / "dataset" / "backend_probe_results.xlsx")
    print(f"Loaded {len(df)} plugins from backend_probe_results.xlsx")

    df_ep = await step_2_2(df)

    df_leak = await step_2_3(df)

    print("\n" + "=" * 60)
    print("COMBINED RQ2 SUMMARY FOR PAPER")
    print("=" * 60)

    n_manifest = len(df[df["manifest_accessible"] == True])
    n_spec = len(df[df["api_spec_accessible"] == True])
    n_fully = len(df[df["backend_status"] == "fully_alive"])
    n_noauth = len(df[(df["backend_status"] == "fully_alive") & (df["manifest_auth_type"] == "none")])

    print(f"\n1. Residual Attack Blueprint:")
    print(f"   - {n_manifest} plugins still expose ai-plugin.json manifest")
    print(f"   - {n_spec} plugins have downloadable OpenAPI spec")
    if len(df_ep) > 0:
        total_eps = len(df_ep)
        print(f"   - {total_eps} total endpoints exposed in {n_noauth} no-auth APIs:")
        print(f"     Method distribution: {df_ep['method'].value_counts().to_dict()}")

    print(f"\n2. Protection Layer Evaporation:")
    print(f"   - {n_noauth}/{n_fully} fully_alive APIs have auth=none")
    print(f"   - All verified to be auth=none since 2024 (no regression)")
    print(f"   - Platform proxy removal = pre-existing flaws → public attack surface")

    print(f"\n3. Information Leakage Cascade:")
    if len(df_leak) > 0:
        crit = len(df_leak[df_leak["severity"] == "critical"])
        high = len(df_leak[df_leak["severity"] == "high"])
        med = len(df_leak[df_leak["severity"] == "medium"])
        low = len(df_leak[df_leak["severity"] == "low"])
        print(f"   Severity: critical={crit}, high={high}, medium={med}, low={low}")
        print(f"   Emails exposed: {df_leak['has_email'].sum()}")
        print(f"   API URLs exposed: {df_leak['has_api_url'].sum()}")

    summary_path = BASE / "analysis_results" / "rq2_attack_surface_summary.txt"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"RQ2 Attack Surface Analysis Summary\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        if len(df_ep) > 0:
            f.write(f"=== Step 2.2: Endpoint Classification (52 no-auth APIs) ===\n")
            f.write(f"Plugins with specs: {df_ep['title'].nunique()}\n")
            f.write(f"Total endpoints: {len(df_ep)}\n")
            f.write(f"Method distribution: {df_ep['method'].value_counts().to_dict()}\n\n")

            f.write(f"--- Per-plugin endpoint summary ---\n")
            for title, grp in df_ep.groupby("title"):
                methods = grp["method"].value_counts().to_dict()
                f.write(f"  {title}: {len(grp)} endpoints methods={methods}\n")

        if len(df_leak) > 0:
            f.write(f"\n=== Step 2.3: Information Leakage (128 manifests) ===\n")
            f.write(f"Severity: {df_leak['severity'].value_counts().to_dict()}\n")
            f.write(f"Emails: {df_leak['has_email'].sum()}\n")
            f.write(f"Legal URLs: {df_leak['has_legal_url'].sum()}\n")
            f.write(f"API URLs: {df_leak['has_api_url'].sum()}\n")
            f.write(f"Server bases: {df_leak['has_server_base'].sum()}\n")
            f.write(f"Full specs: {df_leak['spec_downloadable'].sum()}\n")
            f.write(f"Live endpoints: {df_leak['live_endpoints'].sum()}\n")

    print(f"\nSummary saved: {summary_path}")


if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    asyncio.run(main())
