
import pandas as pd
import numpy as np
import json
import ast
import asyncio
import aiohttp
import ssl
import sys
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent.parent
CONCURRENT = 30
TIMEOUT = 15


async def probe_url(session: aiohttp.ClientSession, sem: asyncio.Semaphore,
                    title: str, url: str, probe_type: str,
                    idx: int, total: int) -> dict:
    async with sem:
        if idx % 50 == 0:
            print(f"  [{idx+1}/{total}] {title}: {url[:60]}...", flush=True)
        result = {
            "title": title,
            "probe_type": probe_type,
            "probe_url": url,
            "status_code": None,
            "content_type": None,
            "is_valid_spec": False,
            "is_valid_manifest": False,
            "response_size": 0,
            "error": None,
        }
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=TIMEOUT),
                                   ssl=False, allow_redirects=True) as resp:
                result["status_code"] = resp.status
                result["content_type"] = resp.headers.get("Content-Type", "")
                body = await resp.text(errors="replace")
                result["response_size"] = len(body)

                if resp.status < 500 and len(body) > 50:
                    try:
                        data = json.loads(body)
                        if "openapi" in data or "swagger" in data or "paths" in data:
                            result["is_valid_spec"] = True
                        if "schema_version" in data or "name_for_human" in data:
                            result["is_valid_manifest"] = True
                    except:
                        if "openapi:" in body[:500] or "swagger:" in body[:500] or "paths:" in body[:1000]:
                            result["is_valid_spec"] = True

        except asyncio.TimeoutError:
            result["error"] = "timeout"
        except aiohttp.ClientConnectorError as e:
            result["error"] = f"conn:{str(e)[:80]}"
        except Exception as e:
            result["error"] = f"{type(e).__name__}:{str(e)[:80]}"

        return result


async def probe_api_endpoint(session: aiohttp.ClientSession, sem: asyncio.Semaphore,
                              title: str, base_url: str, path: str, method: str,
                              idx: int, total: int) -> dict:
    url = base_url.rstrip("/") + "/" + path.lstrip("/")
    async with sem:
        result = {
            "title": title,
            "base_url": base_url,
            "path": path,
            "method": method,
            "full_url": url,
            "status_code": None,
            "error": None,
        }
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=TIMEOUT),
                                   ssl=False, allow_redirects=True) as resp:
                result["status_code"] = resp.status
        except asyncio.TimeoutError:
            result["error"] = "timeout"
        except Exception as e:
            result["error"] = f"{type(e).__name__}:{str(e)[:80]}"
        return result


def extract_api_url_from_manifest(json_info_str):
    if pd.isna(json_info_str):
        return None
    s = str(json_info_str)
    try:
        manifest = json.loads(s.replace("'", '"'))
        url = manifest.get("api", {}).get("url", "")
        if url and url.startswith("http"):
            return url
    except:
        pass
    try:
        manifest = ast.literal_eval(s)
        url = manifest.get("api", {}).get("url", "")
        if url and url.startswith("http"):
            return url
    except:
        pass
    return None


def extract_endpoints_from_spec(api_info_str, max_endpoints=5):
    if pd.isna(api_info_str):
        return [], None
    s = str(api_info_str)
    endpoints = []
    server_base = None
    try:
        data = json.loads(s.replace("'", '"'))
    except:
        try:
            data = ast.literal_eval(s)
        except:
            return [], None

    if not isinstance(data, dict):
        return [], None

    if "servers" in data and isinstance(data.get("servers"), list) and data["servers"]:
        server_base = data["servers"][0].get("url", "") if isinstance(data["servers"][0], dict) else ""
    elif "host" in data:
        scheme = "https"
        if "schemes" in data:
            scheme = data["schemes"][0] if data["schemes"] else "https"
        base_path = data.get("basePath", "")
        server_base = f"{scheme}://{data['host']}{base_path}"

    paths = data.get("paths", {})
    if not isinstance(paths, dict):
        return [], server_base
    for path, methods in list(paths.items())[:max_endpoints]:
        if not isinstance(methods, dict):
            continue
        for method in methods:
            if isinstance(method, str) and method.upper() in ["GET", "POST", "PUT", "DELETE", "PATCH"]:
                endpoints.append((path, method.upper()))
                break

    return endpoints[:max_endpoints], server_base


def extract_auth_type(json_info_str):
    if pd.isna(json_info_str):
        return "unknown"
    s = str(json_info_str)
    try:
        manifest = json.loads(s.replace("'", '"'))
        return manifest.get("auth", {}).get("type", "unknown")
    except:
        pass
    try:
        manifest = ast.literal_eval(s)
        return manifest.get("auth", {}).get("type", "unknown")
    except:
        pass
    return "unknown"


async def main():
    print(f"=== RQ2 Historical API Probe — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")

    df_probe = pd.read_excel(BASE / "dataset" / "backend_probe_results.xlsx")
    df_orig = pd.read_excel(BASE / "dataset" / "Plugin inconsistency and security.xlsx")

    df_orig_dedup = df_orig.drop_duplicates("title", keep="first")
    merged = df_probe.merge(
        df_orig_dedup[["title", "json_info", "api_url", "api_info"]],
        on="title", how="left"
    )

    targets = merged.copy()

    targets["hist_api_url"] = targets["api_url"]
    mask_no_url = targets["hist_api_url"].isna()
    targets.loc[mask_no_url, "hist_api_url"] = targets.loc[mask_no_url, "json_info"].apply(
        extract_api_url_from_manifest
    )

    targets["hist_auth_type"] = targets["json_info"].apply(extract_auth_type)

    has_url = targets[targets["hist_api_url"].notna()].copy()
    print(f"\nTotal plugins: {len(targets)}")
    print(f"With historical API URL: {len(has_url)}")
    print(f"Backend status distribution:")
    print(has_url["backend_status"].value_counts().to_string())
    print(f"\nHistorical auth type distribution:")
    print(has_url["hist_auth_type"].value_counts().to_string())

    print(f"\n{'='*60}")
    print(f"Phase 1: Probing {len(has_url)} historical API spec URLs")
    print(f"{'='*60}")

    sem = asyncio.Semaphore(CONCURRENT)
    connector = aiohttp.TCPConnector(limit=CONCURRENT, ssl=False)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = []
        total = len(has_url)
        for i, (_, row) in enumerate(has_url.iterrows()):
            tasks.append(probe_url(
                session, sem, row["title"], row["hist_api_url"],
                "api_spec", i, total
            ))
        results_spec = await asyncio.gather(*tasks)

    df_spec = pd.DataFrame(results_spec)
    responded = df_spec[df_spec["status_code"].notna() & (df_spec["status_code"] < 500)]
    valid_spec = df_spec[df_spec["is_valid_spec"] == True]

    print(f"\nResults:")
    print(f"  Responded (< 500): {len(responded)} / {len(df_spec)}")
    print(f"  Valid OpenAPI spec: {len(valid_spec)} / {len(df_spec)}")
    print(f"  Status code distribution:")
    print(df_spec["status_code"].value_counts().head(10).to_string())

    print(f"\n{'='*60}")
    print(f"Phase 2: Probing endpoints from historical specs")
    print(f"{'='*60}")

    responded_titles = set(responded["title"].tolist())

    endpoint_probes = []
    for _, row in has_url.iterrows():
        if row.get("domain_alive") != True:
            continue
        endpoints, server_base = extract_endpoints_from_spec(row.get("api_info"))
        if not endpoints and not server_base:
            api_url = str(row["hist_api_url"])
            from urllib.parse import urlparse
            parsed = urlparse(api_url)
            server_base = f"{parsed.scheme}://{parsed.netloc}"
            endpoints = [("/", "GET")]

        if server_base and endpoints:
            for path, method in endpoints[:3]:
                endpoint_probes.append({
                    "title": row["title"],
                    "server_base": server_base,
                    "path": path,
                    "method": method,
                })

    print(f"Endpoint probes to make: {len(endpoint_probes)}")

    if endpoint_probes:
        connector2 = aiohttp.TCPConnector(limit=CONCURRENT, ssl=False)
        async with aiohttp.ClientSession(connector=connector2) as session:
            tasks = []
            total = len(endpoint_probes)
            for i, ep in enumerate(endpoint_probes):
                tasks.append(probe_api_endpoint(
                    session, sem, ep["title"], ep["server_base"],
                    ep["path"], ep["method"], i, total
                ))
            results_ep = await asyncio.gather(*tasks)

        df_ep = pd.DataFrame(results_ep)
        ep_alive = df_ep[df_ep["status_code"].notna() & (df_ep["status_code"] < 500)]

        plugins_with_alive_ep = ep_alive["title"].nunique()
        print(f"\nEndpoint probe results:")
        print(f"  Total probes: {len(df_ep)}")
        print(f"  Alive (< 500): {len(ep_alive)}")
        print(f"  Unique plugins with alive endpoints: {plugins_with_alive_ep}")

        existing_zombies = set(df_probe[df_probe["backend_status"] == "fully_alive"]["title"].tolist())
        all_alive_ep = set(ep_alive["title"].tolist())
        confirmed_zombies = all_alive_ep & existing_zombies
        new_hidden = all_alive_ep - existing_zombies
        print(f"  Confirmed existing zombies: {len(confirmed_zombies)}")
        print(f"  **Hidden zombies (new discoveries):** {len(new_hidden)}")

        if new_hidden:
            hidden_status = has_url[has_url["title"].isin(new_hidden)]["backend_status"].value_counts()
            print(f"\n  Hidden zombie 2026 status breakdown:")
            print(hidden_status.to_string())
    else:
        df_ep = pd.DataFrame()
        new_hidden = set()
        confirmed_zombies = set()

    print(f"\n{'='*60}")
    print(f"Phase 3: Cross-analysis — Historical probe vs 2026 status")
    print(f"{'='*60}")

    for status in ["dead", "domain_only", "manifest_only", "spec_only", "fully_alive"]:
        sub_spec = df_spec[df_spec["title"].isin(
            has_url[has_url["backend_status"] == status]["title"]
        )]
        if len(sub_spec) == 0:
            continue
        resp_count = (sub_spec["status_code"].notna() & (sub_spec["status_code"] < 500)).sum()
        valid_count = (sub_spec["is_valid_spec"] == True).sum()
        ep_count = len(new_hidden & set(has_url[has_url["backend_status"] == status]["title"]))
        print(f"\n  {status} ({len(sub_spec)}):")
        print(f"    Spec URL responded: {resp_count} ({100*resp_count/len(sub_spec):.1f}%)")
        print(f"    Valid spec: {valid_count} ({100*valid_count/len(sub_spec):.1f}%)")
        print(f"    Hidden zombie endpoints: {ep_count}")

    print(f"\n{'='*60}")
    print("Saving results")
    print(f"{'='*60}")

    result_rows = []
    for _, row in has_url.iterrows():
        spec_row = df_spec[df_spec["title"] == row["title"]]
        r = {
            "title": row["title"],
            "backend_status_2026": row["backend_status"],
            "hist_api_url": row["hist_api_url"],
            "hist_auth_type": row["hist_auth_type"],
            "spec_status_code": spec_row["status_code"].values[0] if len(spec_row) > 0 else None,
            "spec_valid": spec_row["is_valid_spec"].values[0] if len(spec_row) > 0 else False,
            "spec_content_type": spec_row["content_type"].values[0] if len(spec_row) > 0 else "",
            "spec_error": spec_row["error"].values[0] if len(spec_row) > 0 else "",
            "has_alive_endpoint": row["title"] in new_hidden,
        }
        result_rows.append(r)

    df_result = pd.DataFrame(result_rows)

    out_path = BASE / "dataset" / "rq2_historical_probe_results.xlsx"
    df_result.to_excel(str(out_path), index=False)
    print(f"Saved: {out_path}")

    if len(df_ep) > 0:
        ep_path = BASE / "dataset" / "rq2_historical_endpoint_probes.xlsx"
        df_ep.to_excel(str(ep_path), index=False)
        print(f"Saved: {ep_path}")

    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")

    total_probed = len(has_url)
    spec_responded = len(responded)
    spec_valid_count = len(valid_spec)
    hidden_count = len(new_hidden)
    confirmed_count = len(confirmed_zombies) if 'confirmed_zombies' in dir() else 0

    print(f"Probed {total_probed} plugins using 2024 historical API URLs")
    print(f"  Spec URL responded: {spec_responded} ({100*spec_responded/total_probed:.1f}%)")
    print(f"  Valid OpenAPI spec still accessible: {spec_valid_count} ({100*spec_valid_count/total_probed:.1f}%)")
    print(f"  Known zombies confirmed: {confirmed_count}")
    print(f"  **Hidden zombies (NEW — not found by standard probe):** {hidden_count}")
    print(f"\nKey insight:")
    print(f"  Even after removing the manifest, {spec_valid_count} plugins still expose their API blueprint")
    print(f"  {hidden_count} plugins have backend endpoints still responding despite appearing 'cleaned up'")

    if new_hidden:
        hidden_df = df_result[df_result["title"].isin(new_hidden)]
        print(f"\nHidden zombie auth distribution:")
        print(hidden_df["hist_auth_type"].value_counts().to_string())

    summary_path = BASE / "analysis_results" / "rq2_historical_probe_summary.txt"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"RQ2 Historical API Probe Summary\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"Hypothesis: Removing manifest does not eliminate attack surface.\n")
        f.write(f"Method: Use 2024 historical api_url to probe plugins that\n")
        f.write(f"  removed their manifest but still have live domains.\n\n")
        f.write(f"Probed: {total_probed} plugins\n")
        f.write(f"Spec URL responded: {spec_responded} ({100*spec_responded/total_probed:.1f}%)\n")
        f.write(f"Valid spec accessible: {spec_valid_count} ({100*spec_valid_count/total_probed:.1f}%)\n")
        f.write(f"Hidden zombies: {hidden_count}\n")
    print(f"Summary saved: {summary_path}")


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(main())
