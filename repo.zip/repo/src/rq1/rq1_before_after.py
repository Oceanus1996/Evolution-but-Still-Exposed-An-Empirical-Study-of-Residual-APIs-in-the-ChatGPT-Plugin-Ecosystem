
import sys
import io
from pathlib import Path

import pandas as pd

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

BASE_DIR = Path(__file__).resolve().parent.parent
SECURITY_FILE = BASE_DIR / "dataset" / "Plugin inconsistency and security.xlsx"
SURVIVAL_FILE = BASE_DIR / "dataset" / "rq1_domain_survival.xlsx"
OUTPUT_XLSX = BASE_DIR / "dataset" / "rq1_before_after.xlsx"
OUTPUT_REPORT = BASE_DIR / "analysis_results" / "before_after_report.md"

def main():
    print("[1/5] Loading data...", flush=True)

    df_sec = pd.read_excel(SECURITY_FILE)
    df_sec = df_sec.drop_duplicates(subset='title', keep='first').reset_index(drop=True)
    print(f"  Baseline security data: {len(df_sec)} plugins (deduplicated)", flush=True)

    df_surv = pd.read_excel(SURVIVAL_FILE)
    print(f"  2026 probe data: {len(df_surv)} plugins", flush=True)

    print("[2/5] Building 2024 baseline...", flush=True)

    df_sec['status_2024'] = df_sec['manifest_Broken'].apply(
        lambda x: 'manifest_broken' if x == 'Y' else 'alive_confirmed'
    )


    baseline = df_sec[['title', 'status_2024', 'manifest_Broken', 'Request_Broken',
                       'Name Inconsistency', 'Legal Inconsistency', 'json_url']].copy()

    alive_confirmed = (baseline['status_2024'] == 'alive_confirmed').sum()
    manifest_broken = (baseline['status_2024'] == 'manifest_broken').sum()
    print(f"  2024 manifest accessible (confirmed alive): {alive_confirmed}", flush=True)
    print(f"  2024 manifest not accessible: {manifest_broken}", flush=True)

    print("[3/5] Comparing 2024 vs 2026...", flush=True)

    df = df_surv.merge(baseline, on='title', how='outer', indicator=True)
    print(f"  Match results:", flush=True)
    print(f"    both: {(df['_merge']=='both').sum()}", flush=True)
    print(f"    left_only (2026 only): {(df['_merge']=='left_only').sum()}", flush=True)
    print(f"    right_only (baseline only): {(df['_merge']=='right_only').sum()}", flush=True)

    df_matched = df[df['_merge'] == 'both'].copy()

    print("[4/5] Classifying transitions...", flush=True)

    def classify_transition(row):
        was_alive = row['status_2024'] == 'alive_confirmed'
        is_alive = row['is_alive'] == True

        if was_alive and is_alive:
            return 'survived'
        elif was_alive and not is_alive:
            return 'died'
        elif not was_alive and is_alive:
            return 'revived'
        else:
            return 'stayed_dead'

    df_matched['transition'] = df_matched.apply(classify_transition, axis=1)

    transition_counts = df_matched['transition'].value_counts()
    print(f"\n  Transition statistics:", flush=True)
    for t, c in transition_counts.items():
        pct = c / len(df_matched) * 100
        print(f"    {t:.<25s} {c:>4d}  ({pct:.1f}%)", flush=True)

    died = df_matched[df_matched['transition'] == 'died']
    print(f"\n  === Plugins that died (alive in 2024 -> dead in 2026): {len(died)} ===", flush=True)

    print(f"\n  Failure modes (HTTP status):", flush=True)
    for status, count in died['http_status'].value_counts().head(10).items():
        print(f"    {status}: {count}", flush=True)

    if 'category' in died.columns:
        print(f"\n  Died plugins by category:", flush=True)
        cat_total = df_matched.groupby('category').size()
        cat_died = died.groupby('category').size()
        cat_df = pd.DataFrame({'died': cat_died, 'total': cat_total}).fillna(0).astype(int)
        cat_df['death_rate'] = (cat_df['died'] / cat_df['total'] * 100).round(1)
        cat_df = cat_df.sort_values('death_rate', ascending=False)
        for cat, row in cat_df.iterrows():
            print(f"    {cat:.<35s} {row['died']}/{row['total']}  ({row['death_rate']}%)", flush=True)

    print("\n[5/5] Saving results...", flush=True)

    output_cols = ['title', 'info', 'domain', 'category',
                   'status_2024', 'manifest_Broken', 'Request_Broken',
                   'is_alive', 'http_status', 'response_time_ms',
                   'transition']
    existing_cols = [c for c in output_cols if c in df_matched.columns]
    df_matched[existing_cols].to_excel(OUTPUT_XLSX, index=False)
    print(f"  Excel: {OUTPUT_XLSX}", flush=True)

    OUTPUT_REPORT.parent.mkdir(parents=True, exist_ok=True)

    total = len(df_matched)
    survived = transition_counts.get('survived', 0)
    died_n = transition_counts.get('died', 0)
    revived = transition_counts.get('revived', 0)
    stayed_dead = transition_counts.get('stayed_dead', 0)

    was_alive_2024 = df_matched[df_matched['status_2024'] == 'alive_confirmed']
    alive_then = len(was_alive_2024)
    died_since = (was_alive_2024['transition'] == 'died').sum()
    still_alive = (was_alive_2024['transition'] == 'survived').sum()

    report = f"""# RQ1: Before/After Comparison Report


**Among {alive_then} plugins confirmed alive in 2024, {died_since} ({died_since/alive_then*100:.1f}%) are no longer reachable in 2026.**

> This demonstrates significant service degradation following the Plugin Store shutdown.


| Dataset | Source | Count |
|---------|--------|-------|
| 2024 baseline | Original security analysis (manifest accessible = confirmed alive) | {alive_then} confirmed alive |
| 2026 status | This study domain probe (HTTP HEAD 2xx/3xx) | {total} matched plugins |


| Transition | Description | Count | Percentage |
|------------|-------------|-------|------------|
| survived | 2024 alive -> 2026 alive | {survived} | {survived/total*100:.1f}% |
| **died** | **2024 alive -> 2026 dead** | **{died_n}** | **{died_n/total*100:.1f}%** |
| revived | 2024 manifest broken -> 2026 alive | {revived} | {revived/total*100:.1f}% |
| stayed_dead | 2024 manifest broken -> 2026 dead | {stayed_dead} | {stayed_dead/total*100:.1f}% |


| Status | Count | Percentage |
|--------|-------|------------|
| Still alive (survived) | {still_alive} | {still_alive/alive_then*100:.1f}% |
| Died | {died_since} | {died_since/alive_then*100:.1f}% |


> During the original study (early 2024), {alive_then} out of {total} plugins had accessible
> manifest endpoints, confirming their domains were operational. In our follow-up probe
> (February 2026), approximately {died_since/alive_then*100:.0f}% of these previously confirmed-alive
> plugins are no longer reachable, demonstrating significant service degradation
> following the ecosystem shutdown.

---

*Generated: 2026-02-08*
*2024 data source: Plugin inconsistency and security.xlsx (ASE 2024)*
*2026 data source: rq1_domain_survival.xlsx (this study)*
"""

    with open(OUTPUT_REPORT, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"  Report: {OUTPUT_REPORT}", flush=True)
    print("\nDone.", flush=True)


if __name__ == "__main__":
    main()
