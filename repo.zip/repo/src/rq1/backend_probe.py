
import asyncio
import aiohttp
import pandas as pd
import json
import sys
import os
import re
import yaml
from pathlib import Path
from datetime import datetime
from urllib.parse import urljoin, urlparse

CONCURRENT = 30
TIMEOUT = 15
PROGRESS_EVERY = 50
BASE = Path(__file__).resolve().parent.parent


def extract_domain_variants(info_url: str) -> list[str]:
    if not info_url or not isinstance(info_url, str):
        return []
    parsed = urlparse(info_url)
    scheme = parsed.scheme or "https"
    host = parsed.netloc or ""
    if not host:
        return []
    base = f"{scheme}://{host}"
    variants = [base]
    if host.startswith("www."):
        variants.append(f"{scheme}://{host[4:]}")
    else:
        variants.append(f"{scheme}://www.{host}")
    return list(dict.fromkeys(variants))


async def fetch_url(session: aiohttp.ClientSession, url: str, method: str = "GET") -> dict:
    start = asyncio.get_event_loop().time()
    try:
        async with session.request(method, url, allow_redirects=True, timeout=aiohttp.ClientTimeout(total=TIMEOUT)) as resp:
            elapsed = (asyncio.get_event_loop().time() - start) * 1000
            text = ""
            try:
                text = await resp.text(encoding="utf-8", errors="replace")
            except Exception:
                pass
            return {"status": resp.status, "text": text, "error": None, "elapsed_ms": round(elapsed, 1)}
    except asyncio.TimeoutError:
        elapsed = (asyncio.get_event_loop().time() - start) * 1000
        return {"status": None, "text": "", "error": "timeout", "elapsed_ms": round(elapsed, 1)}
    except aiohttp.ClientConnectorDNSError:
        return {"status": None, "text": "", "error": "dns_error", "elapsed_ms": 0}
    except aiohttp.ClientConnectorSSLError as e:
        return {"status": None, "text": "", "error": f"ssl_error:{str(e)[:80]}", "elapsed_ms": 0}
    except aiohttp.ClientConnectorError as e:
        return {"status": None, "text": "", "error": f"conn_error:{str(e)[:80]}", "elapsed_ms": 0}
    except Exception as e:
        return {"status": None, "text": "", "error": f"other:{type(e).__name__}:{str(e)[:80]}", "elapsed_ms": 0}


def parse_manifest_json(text: str) -> dict | None:
    try:
        data = json.loads(text)
        if isinstance(data, dict) and ("schema_version" in data or "name_for_human" in data):
            return data
    except (json.JSONDecodeError, ValueError):
        pass
    return None


def parse_openapi_spec(text: str) -> dict | None:
    try:
        data = json.loads(text)
        if isinstance(data, dict) and ("openapi" in data or "swagger" in data or "paths" in data):
            return data
    except (json.JSONDecodeError, ValueError):
        pass
    try:
        data = yaml.safe_load(text)
        if isinstance(data, dict) and ("openapi" in data or "swagger" in data or "paths" in data):
            return data
    except Exception:
        pass
    return None


def extract_api_paths(spec: dict) -> list[dict]:
    endpoints = []
    paths = spec.get("paths", {})
    if not isinstance(paths, dict):
        return endpoints
    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method in ["get", "post", "put", "delete", "patch"]:
            if method in methods:
                endpoints.append({"path": path, "method": method.upper()})
    return endpoints


def get_server_base(spec: dict) -> str | None:
    servers = spec.get("servers", [])
    if isinstance(servers, list) and servers:
        url = servers[0].get("url", "") if isinstance(servers[0], dict) else ""
        if url and url.startswith("http"):
            return url.rstrip("/")
    host = spec.get("host", "")
    if host:
        scheme = "https"
        schemes = spec.get("schemes", [])
        if isinstance(schemes, list) and schemes:
            scheme = schemes[0]
        base_path = spec.get("basePath", "")
        return f"{scheme}://{host}{base_path}".rstrip("/")
    return None


async def probe_domain(session: aiohttp.ClientSession, domain: str) -> dict:
    result = await fetch_url(session, domain, method="HEAD")
    alive = result["status"] is not None and 200 <= result["status"] < 500
    return {
        "domain_status": result["status"],
        "domain_error": result["error"],
        "domain_alive": alive,
        "domain_ms": result["elapsed_ms"],
    }


async def probe_manifest(session: aiohttp.ClientSession, info_url: str, domain: str) -> dict:
    candidates = []
    if domain and isinstance(domain, str):
        base = domain.rstrip("/")
        candidates.append(f"{base}/.well-known/ai-plugin.json")
    for variant in extract_domain_variants(info_url):
        url = f"{variant.rstrip('/')}/.well-known/ai-plugin.json"
        if url not in candidates:
            candidates.append(url)

    for url in candidates:
        result = await fetch_url(session, url)
        if result["status"] == 200 and result["text"]:
            manifest = parse_manifest_json(result["text"])
            if manifest:
                auth = manifest.get("auth", {})
                api_section = manifest.get("api", {})
                api_url = api_section.get("url", "") if isinstance(api_section, dict) else ""
                return {
                    "manifest_accessible": True,
                    "manifest_url": url,
                    "manifest_auth_type": auth.get("type", "") if isinstance(auth, dict) else str(auth),
                    "manifest_api_url": api_url,
                    "manifest_name_for_human": manifest.get("name_for_human", ""),
                    "manifest_legal_info_url": manifest.get("legal_info_url", ""),
                    "manifest_contact_email": manifest.get("contact_email", ""),
                    "manifest_raw": json.dumps(manifest, ensure_ascii=False)[:2000],
                }

    return {
        "manifest_accessible": False,
        "manifest_url": "",
        "manifest_auth_type": "",
        "manifest_api_url": "",
        "manifest_name_for_human": "",
        "manifest_legal_info_url": "",
        "manifest_contact_email": "",
        "manifest_raw": "",
    }


async def probe_api_spec(session: aiohttp.ClientSession, api_url: str) -> dict:
    if not api_url:
        return {
            "api_spec_accessible": False,
            "api_spec_format": "",
            "api_endpoint_count": 0,
            "api_server_base": "",
            "api_endpoints_json": "",
            "api_spec_raw": "",
        }

    result = await fetch_url(session, api_url)
    if result["status"] == 200 and result["text"]:
        spec = parse_openapi_spec(result["text"])
        if spec:
            endpoints = extract_api_paths(spec)
            server_base = get_server_base(spec)
            fmt = "openapi3" if "openapi" in spec else ("swagger2" if "swagger" in spec else "unknown")
            return {
                "api_spec_accessible": True,
                "api_spec_format": fmt,
                "api_endpoint_count": len(endpoints),
                "api_server_base": server_base or "",
                "api_endpoints_json": json.dumps(endpoints, ensure_ascii=False)[:2000],
                "api_spec_raw": result["text"][:3000],
            }

    return {
        "api_spec_accessible": False,
        "api_spec_format": "",
        "api_endpoint_count": 0,
        "api_server_base": "",
        "api_endpoints_json": "",
        "api_spec_raw": "",
    }


async def probe_api_endpoints(session: aiohttp.ClientSession, server_base: str, endpoints: list[dict], max_test: int = 5) -> dict:
    if not server_base or not endpoints:
        return {
            "api_tested_count": 0,
            "api_accessible_count": 0,
            "api_test_results": "",
        }

    test_targets = [e for e in endpoints if e["method"] == "GET"][:max_test]
    if not test_targets:
        test_targets = endpoints[:max_test]

    results = []
    accessible = 0
    for ep in test_targets:
        url = f"{server_base.rstrip('/')}{ep['path']}"
        r = await fetch_url(session, url, method="GET")
        status = r["status"]
        ok = status is not None and status < 500
        if ok:
            accessible += 1
        results.append({"path": ep["path"], "method": ep["method"], "status": status, "error": r["error"]})

    return {
        "api_tested_count": len(results),
        "api_accessible_count": accessible,
        "api_test_results": json.dumps(results, ensure_ascii=False)[:2000],
    }


async def probe_one_plugin(sem: asyncio.Semaphore, session: aiohttp.ClientSession,
                           row: dict, idx: int, total: int) -> dict:
    async with sem:
        result = {"title": row["title"]}

        domain = row.get("domain", "")
        l1 = await probe_domain(session, domain)
        result.update(l1)

        info_url = row.get("info", "")
        l2 = await probe_manifest(session, info_url, domain)
        result.update(l2)

        api_url = l2.get("manifest_api_url", "")
        l3 = await probe_api_spec(session, api_url)
        result.update(l3)

        endpoints = []
        if l3["api_endpoints_json"]:
            try:
                endpoints = json.loads(l3["api_endpoints_json"])
            except Exception:
                pass
        server_base = l3.get("api_server_base", "")
        l4 = await probe_api_endpoints(session, server_base, endpoints)
        result.update(l4)

        if (idx + 1) % PROGRESS_EVERY == 0 or (idx + 1) == total:
            print(f"  [{idx+1}/{total}] {row['title'][:40]}  domain={'OK' if l1['domain_alive'] else 'DEAD'}  "
                  f"manifest={'YES' if l2['manifest_accessible'] else 'NO'}  "
                  f"spec={'YES' if l3['api_spec_accessible'] else 'NO'}  "
                  f"api={l4['api_accessible_count']}/{l4['api_tested_count']}",
                  flush=True)

        return result


async def main():
    print(f"=== Backend Probe - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===", flush=True)

    df = pd.read_excel(BASE / "dataset" / "rq1_domain_survival.xlsx")
    print(f"Loaded {len(df)} plugins", flush=True)

    df_orig = pd.read_excel(BASE / "dataset" / "Plugin inconsistency and security.xlsx")
    print(f"Loaded {len(df_orig)} original security records", flush=True)

    records = df.to_dict("records")
    total = len(records)

    sem = asyncio.Semaphore(CONCURRENT)
    connector = aiohttp.TCPConnector(limit=CONCURRENT, ssl=False)
    async with aiohttp.ClientSession(
        connector=connector,
        headers={"User-Agent": "Mozilla/5.0 (compatible; AcademicResearch/1.0)"}
    ) as session:
        tasks = [probe_one_plugin(sem, session, row, i, total) for i, row in enumerate(records)]
        results = await asyncio.gather(*tasks)

    df_results = pd.DataFrame(results)

    df_orig_slim = df_orig[["title", "manifest_Broken", "Request_Broken", "auth", "json_url", "api_url"]].copy()
    df_orig_slim.columns = ["title", "orig_manifest_broken", "orig_request_broken", "orig_auth", "orig_json_url", "orig_api_url"]
    df_orig_slim = df_orig_slim.drop_duplicates(subset="title", keep="first")

    df_final = df_results.merge(df_orig_slim, on="title", how="left")

    def classify(row):
        if row["domain_alive"] and row["manifest_accessible"] and row["api_spec_accessible"]:
            if row["api_accessible_count"] > 0:
                return "fully_alive"
            return "spec_only"
        if row["domain_alive"] and row["manifest_accessible"]:
            return "manifest_only"
        if row["domain_alive"]:
            return "domain_only"
        return "dead"

    df_final["backend_status"] = df_final.apply(classify, axis=1)

    out_path = BASE / "dataset" / "backend_probe_results.xlsx"

    output_cols = [
        "title",
        "domain_status", "domain_error", "domain_alive", "domain_ms",
        "manifest_accessible", "manifest_url", "manifest_auth_type",
        "manifest_api_url", "manifest_name_for_human", "manifest_legal_info_url",
        "manifest_contact_email",
        "api_spec_accessible", "api_spec_format", "api_endpoint_count", "api_server_base",
        "api_tested_count", "api_accessible_count", "api_test_results",
        "backend_status",
        "orig_manifest_broken", "orig_request_broken", "orig_auth",
    ]
    output_cols = [c for c in output_cols if c in df_final.columns]
    df_final[output_cols].to_excel(str(out_path), index=False)
    print(f"\nSaved to {out_path}", flush=True)

    print(f"\n=== Summary ===")
    print(f"Total plugins: {len(df_final)}")
    print(f"\nBackend status:")
    print(df_final["backend_status"].value_counts().to_string())
    print(f"\nLayer breakdown:")
    print(f"  L1 domain alive:      {df_final['domain_alive'].sum()}/{len(df_final)}")
    print(f"  L2 manifest accessible: {df_final['manifest_accessible'].sum()}/{len(df_final)}")
    print(f"  L3 API spec accessible: {df_final['api_spec_accessible'].sum()}/{len(df_final)}")
    print(f"  L4 API endpoints OK:    {(df_final['api_accessible_count'] > 0).sum()}/{len(df_final)}")

    matched = df_final[df_final["orig_manifest_broken"].notna() | df_final["orig_auth"].notna()]
    if len(matched) > 0:
        was_accessible = matched["orig_manifest_broken"].isna()
        now_accessible = matched["manifest_accessible"] == True
        print(f"\n=== 2024 vs 2026 Manifest Comparison ===")
        print(f"  2024 accessible: {was_accessible.sum()}")
        print(f"  2026 accessible: {now_accessible.sum()}")
        both = (was_accessible & now_accessible).sum()
        lost = (was_accessible & ~now_accessible).sum()
        gained = (~was_accessible & now_accessible).sum()
        print(f"  Still accessible: {both}")
        print(f"  Lost (was OK, now broken): {lost}")
        print(f"  Gained (was broken, now OK): {gained}")


if __name__ == "__main__":
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    asyncio.run(main())
